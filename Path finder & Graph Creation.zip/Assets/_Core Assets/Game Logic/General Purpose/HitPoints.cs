﻿using UnityEngine;

namespace TheTraveler
{
    public class HitPoints : MonoBehaviour
    {
    }
}

